// Jalankan SETELAH `npx cap add android`. Aman dijalankan berulang (idempoten).
// - Izin penyimpanan hanya untuk Android 10 ke bawah (sesuai dokumentasi @capacitor/filesystem)
// - largeHeap: memori lebih longgar untuk memproses banyak frame
import fs from 'node:fs';
const file = process.argv[2] || 'android/app/src/main/AndroidManifest.xml';
if (!fs.existsSync(file)) { console.error('Tidak menemukan ' + file + '. Jalankan "npx cap add android" dulu.'); process.exit(1); }
let x = fs.readFileSync(file, 'utf8'); const before = x; const log = [];
const perms = [
  '<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="29" />',
  '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />'
];
for (const p of perms) {
  const name = p.match(/android:name="([^"]+)"/)[1];
  if (!x.includes(name)) { x = x.replace('</manifest>', '    ' + p + '\n</manifest>'); log.push('izin ' + name.split('.').pop()); }
}
if (!/android:largeHeap=/.test(x)) { x = x.replace(/<application\b/, '<application\n        android:largeHeap="true"'); log.push('largeHeap'); }
if (x === before) console.log('Sudah ter-patch, tidak ada perubahan.');
else { fs.writeFileSync(file, x); console.log('Ditambahkan: ' + log.join(', ')); }
