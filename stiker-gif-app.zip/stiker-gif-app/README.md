# Stiker GIF — project APK (Capacitor 8)

Pembuat stiker GIF animasi dan konverter Video → GIF. Seluruh aplikasi ada di satu file (`www/index.html`),
semua proses berjalan di HP tanpa server. `www/native.js` menambahkan fitur khusus APK (Bagikan, Unduh, layar tetap menyala).

> **Status jujur:** project ini disusun dan diuji di lingkungan tiruan (adaptor native diuji dengan Capacitor palsu).
> **Build APK-nya belum pernah dijalankan** karena lingkungan penyusun tidak punya Android SDK. Pakai daftar uji di bawah.

## 1. Prasyarat (Capacitor 8)
| Alat | Versi |
|---|---|
| Node.js | 22 atau lebih baru |
| JDK | 21 |
| Android Studio | Otter (2025.2.1) atau lebih baru |
| Android SDK | API 36 (minimum perangkat: API 24 / Android 7.0) |

## 2. Membuat APK debug
```bash
npm install
npx cap add android
node scripts/patch-android.mjs          # izin penyimpanan (Android 10-) + largeHeap
npx @capacitor/assets generate --android # ikon & splash dari folder assets/
npx cap sync android
npx cap open android                     # Android Studio: Build > Build APK(s)
```
Atau lewat terminal: `cd android && ./gradlew assembleDebug`
→ hasil: `android/app/build/outputs/apk/debug/app-debug.apk`. Pasang ke HP: `adb install -r app-debug.apk`.

Jalan pintas: `npm run setup` mengerjakan langkah 2–5 sekaligus.

**Opsional (layar tetap menyala saat memproses):** `npm i @capacitor-community/keep-awake` lalu `npx cap sync android`.
Tanpa plugin ini aplikasi tetap jalan, hanya layar bisa mati saat memproses video panjang.

Jika `npm install` menolak sebuah versi, ganti `^8.0.0` pada paket itu dengan `latest`.

## 3. Sebelum dirilis
1. Ganti `appId` di `capacitor.config.json` (sekarang `com.example.stikergif`) dengan ID unik milik Anda.
2. Ubah `webContentsDebuggingEnabled` menjadi `false`.
3. Buat keystore dan tanda tangani: Android Studio > Build > Generate Signed Bundle / APK. **Simpan keystore dan sandinya dengan aman.**
4. Naikkan `versionCode` / `versionName` di `android/app/build.gradle` setiap rilis.

## 4. Memperbarui isi aplikasi
Ganti `www/index.html` (jaga baris `<script src="native.js">` sebelum `</body>`), lalu `npx cap sync android` dan build ulang.

## 5. Perbedaan dibanding versi web
| Fitur | Di APK |
|---|---|
| Bagikan | Menulis file ke cache lalu membuka lembar Bagikan Android (Foto, WhatsApp, Drive, dll.) |
| Unduh | Menyimpan ke `Documents/StikerGIF/`. Android 11+ hanya mengizinkan file buatan aplikasi sendiri di folder ini dan **belum tentu muncul di Galeri**. Jika gagal, otomatis dialihkan ke Bagikan. |
| Layar tetap menyala | Lewat plugin keep-awake (opsional), cadangan: Wake Lock browser |
| WebP untuk WhatsApp | Berjalan di WebView Android. Di iPhone tidak didukung (bukan target project ini) |

## 6. DAFTAR UJI DI HP (wajib sebelum dipakai)
Jalankan `chrome://inspect` di Chrome desktop untuk melihat konsol aplikasi saat HP tersambung USB.

- [ ] Aplikasi terbuka, tampilan atas dan bawah tidak tertutup status bar / tombol navigasi.
- [ ] **Stiker PNG transparan** (tab Sumber) dan **Tempel stiker PNG contoh** (tab Stiker) bekerja. **Simpan PNG contoh** menyimpan ke `Documents/StikerGIF/`; buka PNG itu di aplikasi File/Galeri dan pastikan latarnya tembus pandang.
- [ ] Tab Sumber > **Coba contoh bawaan** (6 gambar bergerak, foto, gambar latar polos, video 3 detik) dan tombol **Pakai video contoh** di mode Video→GIF memuat tanpa error. Video contoh adalah MP4 H.264 (21 KB) yang tertanam di aplikasi.
- [ ] Pilih 3 gambar JPEG/PNG, **Buat Stiker GIF** menghasilkan GIF yang bergerak.
- [ ] **Bagikan** membuka lembar Bagikan dan GIF sampai ke WhatsApp/Foto dalam keadaan bergerak. Tutup lembar tanpa memilih: tidak muncul pesan error.
- [ ] **Unduh**: cek `Documents/StikerGIF/` lewat aplikasi File. Jika gagal, pesan mengarahkan ke Bagikan.
- [ ] Mode **Video→GIF**: video MP4 dari kamera HP 3–5 detik, bagian 📍, hasil benar. Coba juga video panjang dan tombol **Batal**.
- [ ] **Buat WebP untuk WhatsApp**: file diterima oleh aplikasi pembuat paket stiker (mis. Sticker Maker) dan WhatsApp.
- [ ] Gestur jari per menu: Stiker, Teks, dan Gaya (geser/cubit gambar). Tidak ada gestur yang salah sasaran.
- [ ] Kotak warna bawaan HP: garis tepi, isi, dan gradasi stiker berubah di pratinjau.
- [ ] Tombol kembali Android tidak menutup aplikasi saat proses berjalan tanpa sengaja (jika mengganggu, tambahkan plugin @capacitor/app).
- [ ] Memori: video 10 detik, lebar 640, 15 fps tidak membuat aplikasi tertutup sendiri (di HP kelas bawah turunkan lebar/fps).
- [ ] Layar tidak mati saat memproses (jika memasang keep-awake).

## 7. Batasan yang sudah diketahui
- Gambar HEIC dan video HEVC (.mov dari sebagian iPhone) tidak didukung WebView; aplikasi menolaknya dengan pesan.
- Video panjang dengan fps tinggi lambat dan boros memori; aplikasi membatasi maksimal 100 frame.
- GIF hanya mendukung transparansi penuh/tidak sama sekali (gunakan "Haluskan tepi transparan" atau WebP).
- Kunci `Capacitor.Plugins.*` / `nativePromise` dipakai tanpa bundler. Jika konsol menampilkan "Plugin ... tidak tersedia", pastikan `npx cap sync android` sudah dijalankan setelah `npm install`.
