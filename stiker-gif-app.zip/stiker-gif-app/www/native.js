/* Adaptor native Capacitor untuk Stiker GIF.
   Dimuat SETELAH skrip utama di index.html dan hanya aktif di dalam APK.
   Di browser biasa file ini tidak melakukan apa pun. */
(function () {
  const C = window.Capacitor;
  if (!C || !C.isNativePlatform || !C.isNativePlatform()) return;

  // Panggil plugin native: lewat Capacitor.Plugins bila ada, kalau tidak lewat jembatan native.
  const call = (plugin, method, opts) => {
    const p = C.Plugins && C.Plugins[plugin];
    if (p && typeof p[method] === 'function') return p[method](opts || {});
    if (typeof C.nativePromise === 'function') return C.nativePromise(plugin, method, opts || {});
    return Promise.reject(new Error('Plugin ' + plugin + ' tidak tersedia'));
  };
  const hasPlugin = (n) => !!(C.Plugins && C.Plugins[n]) || (typeof C.isPluginAvailable === 'function' && C.isPluginAvailable(n));
  const toBase64 = (b) => new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result).split(',')[1]);
    r.onerror = () => rej(r.error || new Error('Gagal membaca file'));
    r.readAsDataURL(b);
  });
  const stamp = () => new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
  const named = (n) => n.replace(/\.(\w+)$/, '-' + stamp() + '.$1');
  const cancelled = (e) => /cancel|abort|dismiss/i.test(String((e && (e.message || e.name || e.errorMessage)) || ''));
  const why = (e) => (e && (e.message || e.errorMessage)) || String(e);

  // Bagikan: tulis ke cache, lalu buka lembar Bagikan Android dengan URI file.
  async function shareBlob(b, name) {
    try {
      const w = await call('Filesystem', 'writeFile', { path: named(name), data: await toBase64(b), directory: 'CACHE' });
      await call('Share', 'share', { title: 'Stiker', dialogTitle: 'Bagikan stiker', files: [w.uri] });
    } catch (e) {
      if (cancelled(e)) return;
      msg('Gagal membagikan: ' + why(e));
    }
  }

  // Unduh: simpan ke Documents/StikerGIF; bila ditolak (Android 11+), alihkan ke Bagikan.
  sv = async function (b, name) {
    if (!b) { msg('Belum ada file.'); return; }
    try {
      try { await call('Filesystem', 'requestPermissions'); } catch (e) { /* tidak wajib di Android 11+ */ }
      await call('Filesystem', 'writeFile', { path: 'StikerGIF/' + named(name), data: await toBase64(b), directory: 'DOCUMENTS', recursive: true });
      msg('Tersimpan di Documents/StikerGIF \u2713');
    } catch (e) {
      msg('Tidak bisa menyimpan langsung. Pilih tujuan lewat Bagikan.');
      await shareBlob(b, name);
    }
  };
  DL = { save() {} };                     // supaya tombol "Unduh WebP" ikut muncul
  $('dl').hidden = false;
  $('sm_save').hidden = false;           // tombol "Simpan PNG contoh"
  $('sh').onclick = () => (blob ? shareBlob(blob, 'stiker.gif') : msg('Belum ada hasil.'));
  $('ws').onclick = () => (wb ? shareBlob(wb, 'stiker.webp') : msg('Belum ada WebP.'));

  // Layar tetap menyala saat memproses (plugin opsional @capacitor-community/keep-awake).
  const baseBz = bz;
  bz = function (on) {
    baseBz(on);
    if (hasPlugin('KeepAwake')) call('KeepAwake', on ? 'keepAwake' : 'allowSleep').catch(() => {});
  };
})();
